


export class product{
    price:number;
    name:string;
    image:ImageBitmap;
    quantity:number;
}