import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-market-page',
  templateUrl: './market-page.component.html',
  styleUrls: ['./market-page.component.css']
})
export class MarketPageComponent implements OnInit {

  status:boolean;
  middleStatus:boolean;
  slideStatus:boolean;
  public showCart = true;
  searchBox:string;
  public mainDivClass={
    
      "col-lg-9" :!this.showCart,
      "col-lg-10" :this.showCart
  }

  public products = [];//site products object
  public myCartProducts = [];//my cart prodcut object
  public productToShow = [];//object for product 
  public totalPrice = 0;

  constructor(private _product:ProductsService) { }

  ngOnInit(): void {
    this.products = this._product.getProducts();
    this.myCartProducts = this._product.myCart();
    this.productToShow = this._product.productToShow();
  }

  //in myCartProduct for each different product there will be four indexs
  //id, price, quantity, picture
  productCliked(id, name, price, picture){
    let alreadyExits=-1;
    for (let index = 0; index < this.myCartProducts.length; index++) {
      if(this.myCartProducts[index].id==id){//this product is already in my cart
        alreadyExits=1;
        this.myCartProducts[index].quantity+=1;//add one to quantity
      } 
    }
    if(alreadyExits!=1){//if it's new on my cart add as a new product
      let answer = {"id":id,"name":name, "price":price,"quantity":1,"picture":picture};
      this.myCartProducts.push(answer);//push into object
    }
    this.totalPrice+=price;//add the price on this product to the total price
  }
  searchIcon(productToSearch){
    this.middleStatus=true;
    this.productToShow = this._product.productToShow();
    for (let index = 0; index < this.products.length; index++) {
      if(this.products[index].Name.toUpperCase()==productToSearch.toUpperCase()){
        let goToUpdateCenterShow = {"Name":this.products[index].Name, "CatagoryId":this.products[index].CatagoryId,"Price":this.products[index].Price,"Picture":this.products[index].Picture};
        this.productToShow.push(goToUpdateCenterShow);
      }
    }
  }
  
  BackToShowAllProducts(){
    this.middleStatus=false;
  }

  
  showCartFunction(){
    this.showCart=!this.showCart;
    this.slideStatus=!this.slideStatus;
  }
  
  catagoryProduct(catagoryNum){
    this.middleStatus=true;
    this.productToShow = this._product.productToShow();
    for(let index = 0; index < this.products.length; index++) {
      if(this.products[index].CatagoryProduct==catagoryNum){
        let goToUpdateCenterShow = {"Name":this.products[index].Name, "CatagoryId":this.products[index].CatagoryId,"Price":this.products[index].Price,"Picture":this.products[index].Picture};
        this.productToShow.push(goToUpdateCenterShow);
      }
    }
  }

  /// also need to add a trash icon
  deleteFromMyCart(productId){    
    /*
    if(this.totalPrice<0){
      this.totalPrice=0;
    }*/
    //myCartProducts
    let menosPrice;
    for(let index = 0; index < this.myCartProducts.length; index++) {
      if(this.myCartProducts[index].id==productId){
        if(this.myCartProducts[index].quantity>1){//quantity
          this.myCartProducts[index].quantity=this.myCartProducts[index].quantity-1;
          menosPrice=this.myCartProducts[index].price;
        }
        else if(this.myCartProducts[index].quantity==1){ //remove the product details from object
          menosPrice=this.myCartProducts[index].price;
          this.myCartProducts = this.myCartProducts.filter(function(item){
            return item.id !== productId;
          });
        }
      }
    }
    this.totalPrice-=menosPrice;
  }
}
