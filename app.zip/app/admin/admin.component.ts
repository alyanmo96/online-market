import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  status:boolean;
  middleStatus:boolean;
  addStatus:boolean;
  slideStatus:boolean;
  public showCart = true;
  searchBox:string;

  public mainDivClass={
    
      "col-lg-9" :!this.showCart,
      "col-lg-10" :this.showCart
  }

  public products = [];//site products object
  public updateProductObject = [];//object for update product 
  public productToShow = [];//object for search product 

  constructor(private _product:ProductsService) { }

  ngOnInit(): void {
    this.products = this._product.getProducts();
    this.updateProductObject = this._product.adminUpdate();
    this.productToShow = this._product.productToShow();//
  }

  productCliked(name, id, price, picture){
    let goToUpdateSlide = {"Name":name, "CatagoryId":id,"Price":price,"Picture":picture};
    this.updateProductObject = this._product.adminUpdate();
    this.updateProductObject.push(goToUpdateSlide);
   }

   updateProductFunction(event, id, name, price){ 
    for (let index = 0; index < this.products.length; index++) {
      if(this.products[index].CatagoryId==id){
        if(name){
          this.products[index].Name=name;
         // event.target[0].value=" ";
        }
        if(price){
          this.products[index].Price=price;
        }
        if(this.url!=""){
          this.products[index].Picture=this.url;
        }
      }      
    }        
  }

  searchIcon(event, productToSearch){
    this.middleStatus=true;
    this.productToShow = this._product.productToShow();
    for (let index = 0; index < this.products.length; index++) {
      if(this.products[index].Name.toUpperCase()==productToSearch.toUpperCase()){
        let goToUpdateCenterShow = {"Name":this.products[index].Name, "CatagoryId":this.products[index].CatagoryId,"Price":this.products[index].Price,"Picture":this.products[index].Picture};
        this.productToShow.push(goToUpdateCenterShow);
      }
    }
    event.target.searchBox.value=""
  }

  BackToShowAllProducts(){
    this.middleStatus=false;
  }
  url="";

  onSelectFile(e){
     if(e.target.files){
       var reader = new FileReader();
       reader.readAsDataURL(e.target.files[0]);
       reader.onload = (event:any)=>{
         this.url = event.target.result;
       }
     }
  }

  addProductStatus(){
    this.addStatus=!this.addStatus;
  }

  addProductFunction(event, newProductName, newProductPrice){    
    let addJson = {"Name":newProductName,"CatagoryId":44,"Price":newProductPrice,"Picture":this.url,"CatagoryProduct":event.target.selectValue.value};
    this.products.push(addJson);
    event.target.newProductName.value="";
    event.target.newProductPrice.value="";
    event.target.newProductPicture.value="";
  }

  showCartFunction(){
    this.showCart=!this.showCart;
    this.slideStatus=!this.slideStatus;
  }

  catagoryProduct(catagoryNum){
    this.middleStatus=true;
    this.productToShow = this._product.productToShow();
    for(let index = 0; index < this.products.length; index++) {
      if(this.products[index].CatagoryProduct==catagoryNum){
        let goToUpdateCenterShow = {"Name":this.products[index].Name, "CatagoryId":this.products[index].CatagoryId,"Price":this.products[index].Price,"Picture":this.products[index].Picture};
        this.productToShow.push(goToUpdateCenterShow);
      }
    }
  }
  
}