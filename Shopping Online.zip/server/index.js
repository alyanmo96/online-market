const express = require('express');
var cors = require('cors');//to fix: No 'Access-Control-Allow-Origin
const app = express();
const mongoose = require('mongoose');//for create connect with mongo db
const Routers = require('./router/posts');//for any route
const bodyParser = require ('body-parser');//for POST details need this
//app.use(express.bodyParser({limit: '50mb'}));
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));
app.use(cors());
app.use(bodyParser.json());//for POST details need this
app.use('/',Routers);//for GET/POST product/user details

//connection with demo DB
mongoose.connect('mongodb+srv://shopping:Sho881ngMar431@cluster0.ibezp.mongodb.net/product?retryWrites=true&w=majority',
{ useNewUrlParser: true ,useUnifiedTopology: true} ,()=>{
  console.log('connected with DB');
});
mongoose.connection.on('error',(err)=>{//if there is an error return a message
  console.log(err);
});

app.listen(3000);