const mongoose=require('mongoose')

const postOrder = mongoose.Schema({
    numberOfOrders:{
        type:Number,
        required:true
    }    
})

module.exports = mongoose.model('order',postOrder)