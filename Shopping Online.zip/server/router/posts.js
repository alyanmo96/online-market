const express = require('express');
const routers = express.Router();

//next three (GET/POST for products)
routers.get('/getProduct', async (req,res)=>{
   try{
    const Post  = require('./products');
    const posts = await Post.find();
    res.json(posts);
   }
   catch(err){
    res.json({message:err})
   }
});

routers.post('/postProduct', async (req,res)=>{
    const Post  = require('./products');
    const post = new Post({
        Name:req.body.Name,
        Price:req.body.Price,
        Picture:req.body.Picture,
        CategoryId:req.body.CategoryId
    })
    try{
        const savedPost = await post.save()
        res.json(savedPost)
    }catch(err){
        res.json({message:err})
    }
});

routers.post('/products/update',async(req,res)=>{
    const Post  = require('./products');        
    await Post.update({_id: req.body._id},{$set:{Name:req.body.Name ,
                                                    Price:req.body.Price,
                                                    Picture:req.body.Picture,
                                                    CategoryId:req.body.CategoryId}})
    res.json({
        success:true
    })
});

////////////////////////////////////////////////////////////////////////////////////////

//next two (GET/POST for users)
routers.get('/getUser', async (req,res)=>{
    try{
     const Post  = require('./user');
     const posts = await Post.find();
     res.json(posts);
    }
    catch(err){
     res.json({message:err})
    }
 });
 
 routers.post('/postUser', async (req,res)=>{
    const Post  = require('./user');
     const post = new Post({
        firstName:req.body.firstName,
        lastName:req.body.lastName,
        email:req.body.email,
        id:req.body.id,
        city:req.body.city,
        street:req.body.street,
        password:req.body.password,
        role:1
     })
     try{
         const savedPost = await post.save()
         res.json(savedPost)
     }catch(err){
         res.json({message:err})
     }
 });

 //next for orders amount
routers.get('/getOrders', async (req,res)=>{
    try{
     const Post  = require('./orders');
     const posts = await Post.find();
     res.json(posts);
    }
    catch(err){
     res.json({message:err})
    }
 });
 
 routers.post('/postOrders', async (req,res)=>{
    const Post  = require('./orders');
     const post = new Post({
        numberOfOrders:req.body.numberOfOrders
     })
     try{
         const savedPost = await post.save()
         res.json(savedPost)
     }catch(err){
         res.json({message:err})
     }
 });

 routers.post('/orders/update',async(req,res)=>{
    const Post  = require('./orders');        
    await Post.update({_id:'5f4c42e662f38b3a50f33a55'},{$set:{numberOfOrders:req.body.numberOfOrders}});
    res.json({
        success:true
    })
});




module.exports = routers;