const mongoose=require('mongoose')

const postProduct = mongoose.Schema({
    Name:{
        type:String,
        required:true
    },
    Price:{
        type:Number,
        required:true
    },
    Picture:{
        type:String,
        required:true
    },
    CategoryId:{
        type:Number,
        required:true        
    }    
})

module.exports = mongoose.model('ProductItem',postProduct);