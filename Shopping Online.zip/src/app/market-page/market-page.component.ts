import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import{HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-market-page',
  templateUrl: './market-page.component.html',
  styleUrls: ['./market-page.component.css']
})
export class MarketPageComponent implements OnInit {

  closeResult = '';//for popup
  status:boolean;
  public middleStatus:boolean;
  slideStatus:boolean;
  public showCart = true;
  searchBox:string;
  public showPage = -1;

  public mainDivClass={    
      "col-lg-9" :!this.showCart,
      "col-lg-10" :this.showCart
  }

  public products = [];//site products object
  public myCartProducts = [];//my cart prodcut object
  public productToShow = [];//object for product 
  public totalPrice = 0;
  public userID;
  readonly PRODUCT_ROOT_URL;

  constructor(private _product:ProductsService, private modalService: NgbModal, private http : HttpClient) { 
    this.PRODUCT_ROOT_URL = 'http://localhost:3000/getProduct';
  }

  ngOnInit(): void {
    
    this.userID = localStorage.getItem('userId');   

    if(this.userID){
      this.showPage = 1;
    }
    
    try {
      this.http.get(this.PRODUCT_ROOT_URL).toPromise().then(response => {
         let i =0;
           while(response[i]){
           this.products[i]=response[i];
           i++;
         }            
         
       });         
     } catch (exception) {
       console.log('error');
       return;
     }

    this.myCartProducts = this._product.myCart();
    let myLastCartTotalPrice = localStorage.getItem('myLastCartTotalPrice');

    let myLastCart;
    let myLastCartJson;
    let getCartUserId=JSON.parse(localStorage.getItem('myLastCart'));
    
    if(this.userID==getCartUserId[0].userID){
      myLastCart =  localStorage.getItem('myLastCart');
      myLastCartJson = JSON.parse(myLastCart);
    }
    if(myLastCartJson){
      this.myCartProducts = myLastCartJson;

      this.totalPrice=parseInt(myLastCartTotalPrice,10);
    }
    this.productToShow = this._product.productToShow();
  }

  //in myCartProduct for each different product there will be four indexs
  //id, price, quantity, picture
  productCliked(id, name, price, picture, amount){
    let priceMultyByAmount = amount*price;
    let alreadyExits=-1;
    for (let index = 0; index < this.myCartProducts.length; index++) {
      if(this.myCartProducts[index].id==id){//this product is already in my cart
        alreadyExits=1;
        var y: number = +this.myCartProducts[index].quantity;
        var z: number = +amount;
        this.myCartProducts[index].quantity=y+z;//add one to quantity
      } 
    }
    this.totalPrice+=priceMultyByAmount;//add the price on this product to the total price
    if(alreadyExits!=1){//if it's new on my cart add as a new product
      let answer = {"id":id,"name":name, "price":price,"quantity":amount,"picture":picture,"userID":this.userID};
      this.myCartProducts.push(answer);//push into object  
      localStorage.setItem('myLastCart', JSON.stringify(this.myCartProducts));
      localStorage.setItem('myLastCartTotalPrice', JSON.stringify(this.totalPrice));

    }
    
  }
  searchIcon(productToSearch){
    this.middleStatus=true;
    this.productToShow = this._product.productToShow();
    for (let index = 0; index < this.products.length; index++) {
      if(this.products[index].Name.toUpperCase()==productToSearch.toUpperCase()){
        let goToUpdateCenterShow = {"Name":this.products[index].Name, "CatagoryId":this.products[index].CatagoryId,"Price":this.products[index].Price,"Picture":this.products[index].Picture,"userID":this.userID};
        this.productToShow.push(goToUpdateCenterShow);
      }
    }
  }

  
  onSearchChange(searchValue){ 
    if(searchValue.length==0){
      this.productToShow=this._product.productToShow();
    }
    else{
      this.productToShow = this._product.productToShow();
      this.middleStatus=true;
      this.productToShow = this.products.filter(p => (p.Name.toUpperCase().includes(searchValue.toUpperCase())));
    }
  }
  
  BackToShowAllProducts(){
    this.middleStatus=false;
  }

  showCartFunction(){
    this.showCart=!this.showCart;
    this.slideStatus=!this.slideStatus;
  }
  
  catagoryProduct(catagoryNum){
    this.middleStatus=true;
    this.productToShow = this._product.productToShow();
    for(let index = 0; index < this.products.length; index++) {
      if(this.products[index].CategoryId==catagoryNum){
        let goToUpdateCenterShow = {"Name":this.products[index].Name, "CatagoryId":this.products[index].CategoryId,"Price":this.products[index].Price,"Picture":this.products[index].Picture,"userID":this.userID};
        this.productToShow.push(goToUpdateCenterShow);
      }
    }
  }

  deleteFromMyCart(productId){ //myCartProducts

    let menosPrice;
    if(productId==-1){//delete all products on my cart
      localStorage.removeItem("myLastCartTotalPrice");
      localStorage.removeItem("myLastCart");
      this.myCartProducts = this._product.myCart();
      this.totalPrice=0;
      return;      
    }
    //delete on product or less the quantity of it
   for(let index = 0; index < this.myCartProducts.length; index++) {
      
      if(this.myCartProducts[index].id==productId){         
        if(this.myCartProducts[index].quantity>1){//quantity
          this.myCartProducts[index].quantity=this.myCartProducts[index].quantity-1;
          menosPrice=this.myCartProducts[index].price;          
          localStorage.removeItem("myLastCart");
          let answer = {"id":this.myCartProducts[index].id,"name":this.myCartProducts[index].name, "price":this.myCartProducts[index].price,"quantity":this.myCartProducts[index].quantity,"picture":this.myCartProducts[index].picture,"userID":this.userID};
          this.myCartProducts= this._product.myCart();
          this.myCartProducts.push(answer);//push into object 
          localStorage.setItem('myLastCart', JSON.stringify(this.myCartProducts));
          localStorage.removeItem("myLastCartTotalPrice");
          this.totalPrice-=menosPrice;
          localStorage.setItem('myLastCartTotalPrice', JSON.stringify(this.totalPrice));

          index=this.myCartProducts.length+1;
          break;
        }
        else if(this.myCartProducts[index].quantity<=1){ //remove the product details from object
          menosPrice=this.myCartProducts[index].price;
          localStorage.removeItem("myLastCartTotalPrice");
          localStorage.removeItem("myLastCart");
          this.myCartProducts = this._product.myCart();
          this.totalPrice=0;          
          this.myCartProducts = this.myCartProducts.filter(function(item){
            return item.id !== productId;
          });
        }
      }
    }
  }
  
  open(content, id, name, price, picture) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
      let amount =result.value;
      this.productCliked(id, name, price, picture, amount);
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
}