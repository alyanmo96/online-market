import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
//import { concat } from 'rxjs';
import { DomSanitizer } from '@angular/platform-browser';
import { jsPDF } from "jspdf";
import{HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  public showPage = -1;
  closeResult = '';//for popup
  public myCartProducts = [];//my cart prodcut object
  public search = [];
  public middleStatus:boolean;
  public productToShow = [];//object for product 
  public totalPrice = 0;
  public sectionToShow=-1;
  public city : string;
  public street : string;
  readonly GET_USER_ROOT_URL;
  readonly GET_ORDER_ROOT_URL;
  readonly UPDATE_ORDER_ROOT_URL;
  readonly ORDER_ROOT_URL;
  public numberOfOrders;
  
  constructor(private _product:ProductsService, private modalService: NgbModal, private sanitizer: DomSanitizer, private http : HttpClient) {
    this.GET_USER_ROOT_URL = 'http://localhost:3000/getUser';
    this.GET_ORDER_ROOT_URL = 'http://localhost:3000/getOrders';
    this.ORDER_ROOT_URL = 'http://localhost:3000/getOrders';
    this.UPDATE_ORDER_ROOT_URL = 'http://localhost:3000/orders/update';
   }

  ngOnInit(): void {
    this.totalPrice = parseInt(localStorage.getItem('myLastCartTotalPrice'),10);
    this.myCartProducts = this._product.myCart();
    let myLastCart =  localStorage.getItem('myLastCart');
    let myLastCartJson = JSON.parse(myLastCart);
    this.myCartProducts = myLastCartJson;
    let userID =  localStorage.getItem('userId');
    if(userID){
      this.showPage = 1;
    }
    let AllUsers;  
    try{
        AllUsers = this.http.get(this.GET_USER_ROOT_URL).toPromise().then(data=>{
          let i = 0;
          while(data[i]){
              if(data[i]._id == userID){
                this.city = AllUsers[i].city;
                this.street = AllUsers[i].street;
                break;
              }
            i++;
          }
        }); 
      }catch (exception) {
        console.log('error');
        return;
    }

    let AllOrders;  
    try{    
      AllOrders = this.http.get(this.ORDER_ROOT_URL).toPromise().then(data=>{
        let i =0;
        while(data[i]){
          this.numberOfOrders = data[0].numberOfOrders;
          i++;
        }
      }); 
      }catch (exception) {
        console.log('error');
        return;
    }

  }

   ValidateCreditCardNumber(ccNum) {
    var visaRegEx = /^(?:4[0-9]{12}(?:[0-9]{3})?)$/;
    var mastercardRegEx = /^(?:5[1-5][0-9]{14})$/;
    var amexpRegEx = /^(?:3[47][0-9]{13})$/;
    var discovRegEx = /^(?:6(?:011|5[0-9][0-9])[0-9]{12})$/;
    var isValid = false;
    if (visaRegEx.test(ccNum)) {
      isValid = true;
    } else if(mastercardRegEx.test(ccNum)) {
      isValid = true;
    } else if(amexpRegEx.test(ccNum)) {
      isValid = true;
    } else if(discovRegEx.test(ccNum)) {
      isValid = true;
    }
    if(isValid) {
      return 1;
    } else {
       return -1;
    }
  }
  
  open(content ,event) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
      //check validate of  city, street, date, credit card

      if(event.target.City.value==""){
        alert("Please provide a valid City input!");
        return;
      }      
      if(event.target.Street.value==""){
        alert("Please provide a valid Street input!");
        return;
      }   

      let foundASlash=-1;
      let dateDayNum="";
      for (let index = 0; index < event.target.date.value.length; index++) {
        if(foundASlash==1 && event.target.date.value[index]=='/'){
          break;
         }
        if(foundASlash==-1 && event.target.date.value[index]=='/'){
          foundASlash=1;    
          continue;
        }
       if(foundASlash==1){
        dateDayNum+=event.target.date.value[index];
       }        
      }
      var y: number = +dateDayNum;
      var today = new Date();
      var r = today.getUTCDate();
      if(r>y||event.target.date.value==""){
        alert("Please provide a valid Date input!");
        return;
      }      
      if(this.ValidateCreditCardNumber(event.target.Card.value)==-1){
        alert("Please provide a valid Visa number!");
        return;
      }else{
        /// every thing is right
       this.sectionToShow=1;
       localStorage.removeItem("myLastCart");
      localStorage.removeItem("myLastCartTotalPrice");
       this.numberOfOrders+=1;
        let postData={
            numberOfOrders:this.numberOfOrders
          }
          try {
            this.http.post(this.UPDATE_ORDER_ROOT_URL, postData).subscribe(data =>{}); 
            } catch (exception) {
            console.log('error');
            return;
          }
      }
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  
  downloadPDF(){
    const doc = new jsPDF();
    let textToWrite="";
    for (let index = 0; index < this.myCartProducts.length; index++) {
      textToWrite+=this.myCartProducts[index].Name;
      textToWrite+='\t';
      textToWrite+=this.myCartProducts[index].Price;
      textToWrite+='\n';
    } 
    textToWrite+=this.totalPrice;
    doc.text(textToWrite, 10, 10);
    doc.save("a4.pdf");
  }
  
  doubleClick(event){
    if(event.target.name == 'City'){
      event.target.value = this.city;
    }    
    if(event.target.name == 'Street'){
      event.target.value = this.street;
    } 
  }

  
  onSearchChange(searchValue){ 
    if(searchValue.length==0){
      this.productToShow=this._product.productToShow();
    }
    else{
      this.productToShow = this._product.productToShow();
      this.middleStatus=true;
      this.productToShow = this.myCartProducts.filter(p => (p.Name.toUpperCase().includes(searchValue.toUpperCase())));
    }
  }
  

}
