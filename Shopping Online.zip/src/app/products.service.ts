import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private http : HttpClient) { }

  userCity = 'CityNameLine21NeedToTakeFromDB';
  userStreet = 'streetNameLine22NeedToTakeFromDB';
  userCard = '1234567889877';

  logged = false;

  NumberOfOrders = 0;
  NumberOfTransportsAtTheSameDay = 0;
  NumberOfBoughtProducts = 0;
  NumberOfProductsOnSite = 0;


  cities(){
    return [ {"name":"Tel Aviv-Yafo"},
    {"name":"Hifa"},
    {"name":"Eilat"},
    {"name":"Acre"},
    {"name":"Beersheba"},
    {"name":"Nazareth"},
    {"name":"Netanya"},
    {"name":"Safed"},
    {"name":"Tiberias"},
    {"name":"Jerusalem"} ]
  }

  adminUpdate(){
    return[];
  }

  productToShow(){
    return[];
  }

  myCart(){
    return[];
  }
  
  myLastCart(){
    return[];
  }

}
