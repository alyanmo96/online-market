


export class product{
    price:number,
    name:string,
    image:ImageBitmap,
    _id:string,
    category:string
}