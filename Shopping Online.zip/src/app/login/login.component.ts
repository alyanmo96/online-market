import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import{HttpClient} from '@angular/common/http';
import { from } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  public NumberOfBoughtProducts;
  public NumberOfProductsOnSite;
  public startShopping = -1;
  public TodayDate = new Date();
  public loginFor = -1;
  public myLastCart = [];
  public cartDate;
  readonly PRODUCT_ROOT_URL;
  readonly USER_ROOT_URL;
  readonly ORDER_ROOT_URL;
  public userFirstAndLastName:string;

  constructor(private _product:ProductsService, private http : HttpClient) { 
    this.PRODUCT_ROOT_URL = 'http://localhost:3000/getProduct';
    this.USER_ROOT_URL = 'http://localhost:3000/getUser';
    this.ORDER_ROOT_URL = 'http://localhost:3000/getOrders';
  }

  ngOnInit(): void { 
    let order;
    try {
      this.http.get(this.PRODUCT_ROOT_URL).toPromise().then(data=>{
        let counter = 0;
        while(data[counter]){
          counter++;
        }
        counter-=1;
        this.NumberOfProductsOnSite = counter;
      }); 
      } catch (exception) {
        console.log('error');
        return;
      }

      try {
        order  = this.http.get(this.ORDER_ROOT_URL).toPromise(); 
        } catch (exception) {
          console.log('error');
          return;
        }
  
        let AllOrders;  
    try{    
      AllOrders = this.http.get(this.ORDER_ROOT_URL).toPromise().then(data=>{
        let i =0;
        while(data[i]){
          this.NumberOfBoughtProducts = data[0].numberOfOrders;
          i++;
        }
      }); 
      }catch (exception) {
        console.log('error');
        return;
    }    
  }

  checkIfThereAUserByTheseDetails(username:string, password:string){
    if(username == "" || password == ""){
      alert('Fill the input first!');
      return -1;
    }     
    try {
        this.http.get(this.USER_ROOT_URL).toPromise().then(data=>{
          let index =0;         
          localStorage.removeItem("userId");
          while(data[index]){            
            if(data[index].email == username && data[index].password == password && data[index].role == 1){//normal user
              this.userFirstAndLastName = data[index].firstName;
              this.userFirstAndLastName += " ";
              this.userFirstAndLastName += data[index].lastName; 
              localStorage.setItem('userId', JSON.stringify(data[index]._id));
              return 1;
            }else if(data[index].email == username && data[index].password == password && data[index].role == 2){// ADMIN
              localStorage.setItem('userId', JSON.stringify(1));
             return 2;
            }else if(data[index].email == username && data[index].password != password){// incorrect password
              alert('incorrect pasword!');
              return -1;
            }
            index++;
          }
          alert('incorrect username!!!');
          return -1;
        }); 
      } catch (exception) {
        console.log('error');
        return;
      }
  }

  Login(event){//check on users 
    let username = event.target.userName.value;
    let password = event.target.Password.value;
    let checkIfThereAUserByTheseDetails = this.checkIfThereAUserByTheseDetails(username, password);

    var user =  localStorage.getItem('userId');
    
    if(checkIfThereAUserByTheseDetails==-1){
      return;
    }
    this.startShopping = 1;

    if(checkIfThereAUserByTheseDetails==1){
      var objectArray =  localStorage.getItem('objectArray');
      var objArr = JSON.parse(objectArray);
      if(objArr){//continue to buy more products
        this.loginFor = 2; 
      }else{
        this.myLastCart = this._product.myLastCart();
        if(this.myLastCart.length > 0){//there was a cart before 
          this.loginFor = 3; 
          this.cartDate = localStorage.getItem('date');
        }else{//no cart before, return a message
          this.loginFor = 4;
        }      
      } 
      return;
    }
    if(parseInt(user,10)==1){
      this.loginFor = 1;
    }
    else{
      this.loginFor = 2;
    }
    if(checkIfThereAUserByTheseDetails==2){
      this.loginFor = 1; 
    }   
  }
}
