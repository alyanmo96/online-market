import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {SignUpComponent} from './sign-up/sign-up.component';
import {LoginComponent} from './login/login.component';
import {AdminComponent} from './admin/admin.component';
import {MarketPageComponent} from './market-page/market-page.component';
import {PaymentComponent} from './payment/payment.component';



const routes: Routes = [
  {

  }
];

const router = [
  {path: "signUp", component:SignUpComponent},
  {path: "login", component:LoginComponent},
  {path: "Admin", component:AdminComponent},
  {path: "Market", component:MarketPageComponent},
  {path: "payment", component:PaymentComponent},
  {path:'', redirectTo:'/login', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(router)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
