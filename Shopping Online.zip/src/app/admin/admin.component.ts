import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import{HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  status:boolean;
  middleStatus:boolean;
  addStatus:boolean;
  slideStatus:boolean;
  public showCart = true;
  imageUrl:File
  searchBox:string;
  readonly POST_USER_ROOT_URL;
  readonly GET_PRODUCT_ROOT_URL;
  readonly UPDATE_PRODUCT_ROOT_URL;

  public mainDivClass={
    
      "col-lg-9" :!this.showCart,
      "col-lg-10" :this.showCart
  }

  public products = [];//site products
  public updateProductObject = [];//object for update product 
  public productToShow = [];//object for search product 
  constructor(private _product:ProductsService, private http : HttpClient) {
    this.POST_USER_ROOT_URL = 'http://localhost:3000/postProduct';
    this.GET_PRODUCT_ROOT_URL = 'http://localhost:3000/getProduct';
    this.UPDATE_PRODUCT_ROOT_URL = 'http://localhost:3000/products/update';
   }

  ngOnInit(): void {
    this.updateProductObject = this._product.adminUpdate();
    this.productToShow = this._product.productToShow();

    try {
       this.http.get(this.GET_PRODUCT_ROOT_URL).toPromise().then(response => {
          let i =0;
            while(response[i]){
            this.products[i]=response[i];
            i++;
          }            
          
        });         
      } catch (exception) {
        console.log('error');
        return;
      }
  }

  productCliked(name, id, price, picture){
    let goToUpdateSlide = {"Name":name, "_id":id,"Price":price,"Picture":picture};
    this.updateProductObject = this._product.adminUpdate();
    this.updateProductObject.push(goToUpdateSlide);
   }

   updateProductFunction(event, id, name, price){   
   for (let index = 0; index < this.products.length; index++) {  
      if(this.products[index]._id==id){
        // insert into DB
        let postData={
          _id:id,
          Name:name,
          Price:price,
          Picture:this.url
        }
      try {
        this.http.post(this.UPDATE_PRODUCT_ROOT_URL, postData).subscribe(data =>{}); 
        } catch (exception) {
          console.log('error');
          return;
        }
        break;
      }      
    }  
  }

  searchIcon(event, productToSearch){
    this.middleStatus=true;
    this.productToShow = this._product.productToShow();
    for (let index = 0; index < this.products.length; index++) {
      if(this.products[index].Name.toUpperCase()==productToSearch.toUpperCase()){
        let goToUpdateCenterShow = {"Name":this.products[index].Name, "CatagoryId":this.products[index].CatagoryId,"Price":this.products[index].Price,"Picture":this.products[index].Picture};
        this.productToShow.push(goToUpdateCenterShow);
      }
    }
    event.target.searchBox.value=""
  }

  BackToShowAllProducts(){
    this.middleStatus=false;
  }
  url="";

  onSelectFile(e){
     if(e.target.files){
       var reader = new FileReader();
       reader.readAsDataURL(e.target.files[0]);
       reader.onload = (event:any)=>{
         this.url = event.target.result;
       }
     }
  }

  addProductStatus(){
    this.addStatus=!this.addStatus;
  }

  addProductFunction(event){       
     // insert into DB
    let postData={
      Name:event.target.newProductName.value,
      Price:event.target.newProductPrice.value,
      Picture:this.url,
      CategoryId:event.target.selectValue.value
    }
    event.target.newProductName.value="";
    event.target.newProductPrice.value="";
    event.target.newProductPicture.value="";

    try {
      this.http.post(this.POST_USER_ROOT_URL, postData).subscribe(data =>{       
      }); 
      } catch (exception) {
        console.log('error');
        return;
      }
  }

  showCartFunction(){
    this.showCart=!this.showCart;
    this.slideStatus=!this.slideStatus;
  }

  catagoryProduct(catagoryNum){
    this.middleStatus=true;
    this.productToShow = this._product.productToShow();
    for(let index = 0; index < this.products.length; index++) {
      if(this.products[index].CategoryId==catagoryNum){
        let goToUpdateCenterShow = {"Name":this.products[index].Name, "CatagoryId":this.products[index].CategoryId,"Price":this.products[index].Price,"Picture":this.products[index].Picture};
        this.productToShow.push(goToUpdateCenterShow);
      }
    }
  }
}