import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import{HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  public signUpstepOne=1;
  public cities = [];
  public error = -1;
  public errorMessage="";
  public validNewUserDetails = -1;
  readonly GET_USER_ROOT_URL;
  readonly POST_USER_ROOT_URL;

  protected id;
  protected email;
  protected password;

  constructor(private _product:ProductsService, private http : HttpClient) { 
    this.POST_USER_ROOT_URL = 'http://localhost:3000/postUser';
    this.GET_USER_ROOT_URL = 'http://localhost:3000/getUser';
  }

  ngOnInit(): void {
     this.cities = this._product.cities();
     localStorage.removeItem("userId");
  }

  validateEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }

  errorInput(message){
    this.error=1;//to diplay error message
    this.errorMessage=message;//the error message that will display
    return;
  }
  signUpStepOne(event){
    //let idd=this.checkIdIsNotExits(event.target.ID.value);
    if(event.target.ID.value==""){
      this.errorInput("Please provide a valid ID input!");
      return;
    }
    let AllUsers;  
    let check=-1;    
    try {
        AllUsers = this.http.get(this.GET_USER_ROOT_URL).toPromise().then(data=>{
          let i = 0;
          while(data[i]){
            if(data[i].id==parseInt(event.target.ID.value,10)){           
              check=1;
              this.errorInput("provided ID number is already exits. Please provide a valid ID input!");
              return;
            }
            i++;
          }
        }); 
      } catch (exception) {
        console.log('error');
        return;
      }  

    if(event.target.email.value=="" || !this.validateEmail(event.target.email.value)){
      this.errorInput("Please provide a valid email input!");
      return;
    }
    if(event.target.password.value=="" || event.target.password.value.length < 6){
      this.errorInput("Please provide a valid password input!");
      return;
    }
    if(event.target.confirmPassword.value==""){
      this.errorInput("Please provide a valid confirm password input!");
      return;
    }
    if(event.target.password.value!=event.target.confirmPassword.value){
      this.errorInput("passwords input are not equals!");
      return;
    }
    this.signUpstepOne=-1;

    this.id = event.target.ID.value;
    this.email = event.target.email.value;
    this.password = event.target.confirmPassword.value;
  }

  //chack validate of seconde step inputs
  signUpStepTwo(event){
    if(event.target.city.value==""){
      this.errorInput("Please provide a valid city input!");
      return;
    }
    if(event.target.street.value==""){
      this.errorInput("Please provide a valid street input!");
      return;
    }
    if(event.target.firstName.value==""){
      this.errorInput("Please provide a valid first name input!");
      return;
    }
    if(event.target.lastName.value==""){
      this.errorInput("Please provide a valid last name input!");
      return;
    }
    // insert into DB
    let postData={
      firstName:event.target.firstName.value,
      lastName:event.target.lastName.value,
      email:this.email,
      id:this.id,
      city:event.target.city.value,
      street:event.target.street.value,
      password:this.password,
      role:1
    }
    try {
      this.http.post(this.POST_USER_ROOT_URL, postData).subscribe(data =>{   
      }); 
      } catch (exception) {
        console.log('error');
        return;
      }


      let newUserId;
      try {
         this.http.get(this.GET_USER_ROOT_URL).toPromise().then(data=>{
          let i = 0;
          while(data[i]){
            i++;
          }
          i--;
          newUserId=data[i]._id;
        }); 
      } catch (exception) {
        console.log('error');
        return;
      } 


    this.validNewUserDetails = 1;
    localStorage.setItem('userID', JSON.stringify(newUserId));
  }
}
